import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import javax.swing.*;

public class PacMan extends JPanel implements ActionListener {
    private int rowCount = GameConfig.ROW_COUNT;
    private int columnCount = GameConfig.COLUMN_COUNT;
    private int tileSize = GameConfig.TILE_SIZE;
    private int boardWidth = GameConfig.BOARD_WIDTH;
    private int boardHeight = GameConfig.BOARD_HEIGHT;

    private Image wallImage;
    private Image blueGhostImage;
    private Image orangeGhostImage;
    private Image pinkGhostImage;
    private Image redGhostImage;

    private Image pacmanUpImage;
    private Image pacmanDownImage;
    private Image pacmanLeftImage;
    private Image pacmanRightImage;

    private static final int PACMAN_SPEED = 8;
    private static final int GHOST_SPEED = 4;

    HashSet<Block> walls;
    HashSet<Block> foods;
    HashSet<Block> ghosts;
    Block pacman;

    Timer gameLoop;
    char[] directions = GameConfig.DIRECTIONS; //up down left right
    char nextDirection = ' ';
    int score = 0;
    int lives = 3;
    boolean gameOver = false;

    public PacMan() {
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        setBackground(Color.BLACK);
        InputHandler ih = new InputHandler(this);
        addKeyListener(ih);
        setFocusable(true);

        // load images (keep original resource names/paths)
        wallImage = SpriteLoader.load("./wall.png");
        blueGhostImage = SpriteLoader.load("./blueGhost.png");
        orangeGhostImage = SpriteLoader.load("./orangeGhost.png");
        pinkGhostImage = SpriteLoader.load("./pinkGhost.png");
        redGhostImage = SpriteLoader.load("./redGhost.png");

        pacmanUpImage = SpriteLoader.load("./pacmanUp.png");
        pacmanDownImage = SpriteLoader.load("./pacmanDown.png");
        pacmanLeftImage = SpriteLoader.load("./pacmanLeft.png");
        pacmanRightImage = SpriteLoader.load("./pacmanRight.png");

        loadMap();
        for (Block ghost : ghosts) {
            char newDirection = directions[GameConfig.RANDOM.nextInt(4)];
            ghost.updateDirection(newDirection);
        }
        // how long it takes to start timer, milliseconds gone between frames
        gameLoop = new Timer(50, this); //20fps (1000/50)
        gameLoop.start();
    }

    public void loadMap() {
        walls = new HashSet<Block>();
        foods = new HashSet<Block>();
        ghosts = new HashSet<Block>();

        // set static references in Block so updateDirection still functions unchanged
        Block.walls = walls;
        Block.tileSize = tileSize;

        for (int r = 0; r < rowCount; r++) {
            for (int c = 0; c < columnCount; c++) {
                String row = TileMap.TILE_MAP[r];
                char tileMapChar = row.charAt(c);

                int x = c * tileSize;
                int y = r * tileSize;

                if (tileMapChar == 'X') { //block wall
                    Block wall = new Block(wallImage, x, y, tileSize, tileSize);
                    walls.add(wall);
                } else if (tileMapChar == 'b') { //blue ghost
                    Block ghost = new Block(blueGhostImage, x, y, tileSize, tileSize);
                    ghost.speed = GHOST_SPEED;
                    ghosts.add(ghost);
                } else if (tileMapChar == 'o') { //orange ghost
                    Block ghost = new Block(orangeGhostImage, x, y, tileSize, tileSize);
                    ghost.speed = GHOST_SPEED;
                    ghosts.add(ghost);
                } else if (tileMapChar == 'p') { //pink ghost
                    Block ghost = new Block(pinkGhostImage, x, y, tileSize, tileSize);
                    ghost.speed = GHOST_SPEED;
                    ghosts.add(ghost);
                } else if (tileMapChar == 'r') { //red ghost
                    Block ghost = new Block(redGhostImage, x, y, tileSize, tileSize);
                    ghost.speed = GHOST_SPEED;
                    ghosts.add(ghost);
                } else if (tileMapChar == 'P') { //pacman
                    pacman = new Block(pacmanRightImage, x, y, tileSize, tileSize);
                    pacman.speed = PACMAN_SPEED;
                } else if (tileMapChar == ' ') { //food
                    Block food = new Block(null, x + 14, y + 14, 4, 4);
                    foods.add(food);
                }
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        if (pacman != null && pacman.image != null) {
            g.drawImage(pacman.image, pacman.x, pacman.y, pacman.width, pacman.height, null);
        }

        for (Block ghost : ghosts) {
            if (ghost.image != null) {
                g.drawImage(ghost.image, ghost.x, ghost.y, ghost.width, ghost.height, null);
            }
        }

        for (Block wall : walls) {
            if (wall.image != null) {
                g.drawImage(wall.image, wall.x, wall.y, wall.width, wall.height, null);
            }
        }

        g.setColor(Color.WHITE);
        for (Block food : foods) {
            g.fillRect(food.x, food.y, food.width, food.height);
        }
        //score
        g.setFont(new Font("Arial", Font.PLAIN, 18));
        if (gameOver) {
            g.drawString("Game Over: " + String.valueOf(score), tileSize / 2, tileSize / 2);
        } else {
            g.drawString("x" + String.valueOf(lives) + " Score: " + String.valueOf(score), tileSize / 2, tileSize / 2);
        }
    }

    public void move() {

        if (nextDirection != ' ' && canTurn(pacman, nextDirection)) {
            pacman.direction = nextDirection;
            pacman.updateVelocity();

            switch (nextDirection) {
                case 'U' -> pacman.image = pacmanUpImage;
                case 'D' -> pacman.image = pacmanDownImage;
                case 'L' -> pacman.image = pacmanLeftImage;
                case 'R' -> pacman.image = pacmanRightImage;
            }

        }

        pacman.x += pacman.velocityX;
        pacman.y += pacman.velocityY;

        if (pacman.x < -pacman.width) {
            pacman.x = boardWidth;
        }
        else if (pacman.x > boardWidth) {
            pacman.x = -pacman.width;
        }

        for (Block wall : walls) {
            if (Collision.collision(pacman, wall)) {
                pacman.x -= pacman.velocityX;
                pacman.y -= pacman.velocityY;
                break;
            }
        }

        //check ghost collisions
        for (Block ghost : ghosts) {
            if (Collision.collision(ghost, pacman)) {
                lives -= 1;
                if (lives == 0) {
                    gameOver = true;
                    return;
                }
                resetPositions();
            }

            if (ghost.y == tileSize * 9 && ghost.direction != 'U' && ghost.direction != 'D') {
                ghost.updateDirection('U');
            }
            ghost.x += ghost.velocityX;
            ghost.y += ghost.velocityY;
            for (Block wall : walls) {
                if (Collision.collision(ghost, wall) || ghost.x <= 0 || ghost.x + ghost.width >= boardWidth) {
                    ghost.x -= ghost.velocityX;
                    ghost.y -= ghost.velocityY;
                    char newDirection = directions[GameConfig.RANDOM.nextInt(4)];
                    ghost.updateDirection(newDirection);
                }
            }
        }

        //check food collision
        Block foodEaten = null;
        for (Block food : foods) {
            if (Collision.collision(pacman, food)) {
                foodEaten = food;
                score += 10;
            }
        }
        if (foodEaten != null) {
            foods.remove(foodEaten);
        }

        if (foods.isEmpty()) {
            loadMap();
            resetPositions();
        }
    }

    public void resetPositions() {
        pacman.reset();
        pacman.velocityX = 0;
        pacman.velocityY = 0;
        for (Block ghost : ghosts) {
            ghost.reset();
            ghost.speed = GHOST_SPEED;
            char newDirection = directions[GameConfig.RANDOM.nextInt(4)];
            ghost.updateDirection(newDirection);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        move();
        repaint();
        if (gameOver) {
            gameLoop.stop();
        }
    }

    // Called by InputHandler
    public void handleKeyReleased(KeyEvent e) {
        if (gameOver) {
            loadMap();
            resetPositions();
            lives = 3;
            score = 0;
            gameOver = false;
            gameLoop.start();
        }
        // System.out.println("KeyEvent: " + e.getKeyCode());
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            nextDirection = 'U';
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            nextDirection = 'D';
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            nextDirection = 'L';
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            nextDirection = 'R';
        }

    }

    private boolean canTurn(Block b, char dir) {
        int offset = 2; // toleransi kecil
        int testX = b.x;
        int testY = b.y;

        if (dir == 'U') testY -= offset;
        if (dir == 'D') testY += offset;
        if (dir == 'L') testX -= offset;
        if (dir == 'R') testX += offset;

        for (Block wall : walls) {
            if (testX < wall.x + wall.width &&
                testX + b.width > wall.x &&
                testY < wall.y + wall.height &&
                testY + b.height > wall.y) {
                return false;
            }
        }
        return true;
    }


}

import java.util.HashSet;

public class GhostManager {
    private HashSet<Block> ghosts;

    public GhostManager() {
        ghosts = new HashSet<>();
    }

    public HashSet<Block> getGhosts() {
        return ghosts;
    }

    public void add(Block g) {
        ghosts.add(g);
    }

    public void clear() {
        ghosts.clear();
    }
}

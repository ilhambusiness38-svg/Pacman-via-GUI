import java.awt.Image;
import java.util.HashSet;

public class Block {
    public int x;
    public int y;
    public int width;
    public int height;
    public Image image;

    public int startX;
    public int startY;
    public char direction = 'U'; // U D L R
    public int velocityX = 0;
    public int velocityY = 0;
    public int speed = 0;    

    // Shared static references used so updateDirection can check walls and tile size
    public static HashSet<Block> walls;
    public static int tileSize;

    public Block(Image image, int x, int y, int width, int height) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.startX = x;
        this.startY = y;
    }

    public void updateDirection(char direction) {
        char prevDirection = this.direction;
        this.direction = direction;
        updateVelocity();
        this.x += this.velocityX;
        this.y += this.velocityY;
        if (Block.walls != null) {
            for (Block wall : Block.walls) {
                if (Collision.collision(this, wall)) {
                    this.x -= this.velocityX;
                    this.y -= this.velocityY;
                    this.direction = prevDirection;
                    updateVelocity();
                }
            }
        }
    }

    public void updateVelocity() {
        if (this.direction == 'U') {
            this.velocityX = 0;
            this.velocityY = -speed;
        } else if (this.direction == 'D') {
            this.velocityX = 0;
            this.velocityY = speed;
        } else if (this.direction == 'L') {
            this.velocityX = -speed;
            this.velocityY = 0;
        } else if (this.direction == 'R') {
            this.velocityX = speed;
            this.velocityY = 0;
        }
    }

    public void reset() {
        this.x = this.startX;
        this.y = this.startY;
    }
}

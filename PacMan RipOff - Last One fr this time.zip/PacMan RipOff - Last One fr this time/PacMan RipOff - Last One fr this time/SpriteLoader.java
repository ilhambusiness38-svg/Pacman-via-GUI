import java.awt.Image;
import javax.swing.ImageIcon;

public class SpriteLoader {
    public static Image load(String path) {
        // Keep same resource paths as original (e.g. "./wall.png") to avoid asset mismatches
        return new ImageIcon(SpriteLoader.class.getResource(path)).getImage();
    }
}

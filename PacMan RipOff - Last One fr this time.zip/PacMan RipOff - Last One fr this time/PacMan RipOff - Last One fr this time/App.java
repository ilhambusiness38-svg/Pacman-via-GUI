import javax.swing.JFrame;

public class App {
    public static void main(String[] args) throws Exception {
        int rowCount = GameConfig.ROW_COUNT;
        int columnCount = GameConfig.COLUMN_COUNT;
        int tileSize = GameConfig.TILE_SIZE;
        int boardWidth = columnCount * tileSize;
        int boardHeight = rowCount * tileSize;

        JFrame frame = new JFrame("Pac Man");
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        PacMan pacmanGame = new PacMan();
        frame.add(pacmanGame);
        frame.pack();
        pacmanGame.requestFocus();
        frame.setVisible(true);
    }
}

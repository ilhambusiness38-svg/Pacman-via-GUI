import java.util.HashSet;

public class FoodManager {
    private HashSet<Block> foods;

    public FoodManager() {
        foods = new HashSet<>();
    }

    public HashSet<Block> getFoods() {
        return foods;
    }

    public void add(Block b) {
        foods.add(b);
    }

    public void remove(Block b) {
        foods.remove(b);
    }

    public void clear() {
        foods.clear();
    }

    public boolean isEmpty() {
        return foods.isEmpty();
    }
}

import java.util.HashSet;

public class WallManager {
    private HashSet<Block> walls;

    public WallManager() {
        this.walls = new HashSet<>();
    }

    public HashSet<Block> getWalls() {
        return walls;
    }

    public void add(Block b) {
        walls.add(b);
    }

    public void clear() {
        walls.clear();
    }
}
